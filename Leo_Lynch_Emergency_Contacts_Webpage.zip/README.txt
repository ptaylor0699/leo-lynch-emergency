LEO LYNCH EMERGENCY CONTACT WEBPAGE

Upload index.html to a free static web host. Once it has a public HTTPS
address, make ONE QR code pointing to that webpage address.

The QR should point to the webpage URL rather than directly containing
multiple phone numbers. The webpage uses tel: links so the CALL buttons
can open the phone dialler on iPhone and Android.
